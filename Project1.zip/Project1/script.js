const slides = [
    { title: "Slide 1", color: "Red", audio: "audio1.mp3" },
    { title: "Slide 2", color: "Blue", audio: "audio1.mp3" },
    { title: "Slide 3", color: "Green", audio: "audio1.mp3" },
    { title: "Slide 4", color: "Yellow", audio: "audio1.mp3" },
    { title: "Slide 5", color: "Crimson", audio: "audio1.mp3" }
  ];
  
  let currentSlide = 0;
  
  const slideContainer = document.getElementById("slide-container");
  const slideTitle = document.getElementById("slide-title");
  const audioPlayer = document.getElementById("slide-audio");
  
  function updateSlide() {
    const slide = slides[currentSlide];
    slideContainer.style.backgroundColor = slide.color;
    slideTitle.textContent = slide.title;
    audioPlayer.src = slide.audio;
    audioPlayer.play();
  }
  
  function nextSlide() {
    currentSlide = (currentSlide + 1);
    updateSlide();
  }
  
  function prevSlide() {
    currentSlide = (currentSlide - 1);
    updateSlide();
  }
  
  // Initialize first slide
  updateSlide();